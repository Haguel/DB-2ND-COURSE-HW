DELETE FROM contract_contract_details;

DELETE FROM contract_details;

DELETE FROM contracts;

DELETE FROM products;

DELETE FROM categories;

DELETE FROM companies;

DELETE FROM owners;
